package org.maltparser.core.syntaxgraph.ds2ps;
/**
*
*
* @author Johan Hall
*/
public interface Dependency2PhraseStructure {

}
