package org.maltparser.core.syntaxgraph.node;

public interface TerminalNode extends PhraseStructureNode {

}
