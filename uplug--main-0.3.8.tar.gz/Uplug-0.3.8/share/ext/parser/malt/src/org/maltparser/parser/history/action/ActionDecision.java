package org.maltparser.parser.history.action;

/**
*
* @author Johan Hall
* @since 1.1
**/
public interface ActionDecision {
	public void clear();
}
