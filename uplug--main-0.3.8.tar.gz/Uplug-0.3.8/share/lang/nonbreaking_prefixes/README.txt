The language suffix can be found here:

http://www.loc.gov/standards/iso639-2/php/code_list.php


